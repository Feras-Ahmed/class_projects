//
//  main.cpp
//  test 3
//
//  Created by Feras Ahmed on 9/1/15.
//  Copyright (c) 2015 Feras Ahmed. All rights reserved.
//


#include <iostream>

using namespace std;

const double servicecharge = .015;

int main (){
    
    int numSharesSold;
    double purchasepricePerShare;
    double sellingpricePerShare;
    
    cout << "Enter the number of shares sold: " << endl;
    cin >> numSharesSold;
    
    cout << "Enter the purchase price of each share: " << endl;
    cin >> purchasepricePerShare;
    
    cout << "Enter the selling price of each share: " << endl;
    cin >> sellingpricePerShare;
    
    double amountInvested= (purchasepricePerShare*numSharesSold);
    
    cout << "Amount Invested: $" << amountInvested << endl;
    
    double totalServicecharges = (numSharesSold*servicecharge);
    cout << "Total Service Charges: $" << totalServicecharges << endl;
    
    double amountGainorLoss = ((sellingpricePerShare*numSharesSold)-(purchasepricePerShare*numSharesSold));
    cout << "Amount Gained or Lost: $" << amountGainorLoss << endl;
    
    double netincome = (sellingpricePerShare*numSharesSold*servicecharge)-(purchasepricePerShare*numSharesSold*servicecharge);
    cout << "Total amount recieved after selling the stock: $" << netincome << endl;
        
        return 0;
}