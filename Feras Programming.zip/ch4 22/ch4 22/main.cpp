//  main.cpp
//  ch4 22
//  Created by Feras Ahmed on 10/4/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#include <iostream>

using namespace std;

int main (){
    
    int num =0;
    
    cout << "Enter a positive integer between 1 and 1000(inclusive): " << endl;
    cin >> num;
    
    if (num >= 0 && num <= 1000)
    {
        if ((num % 2 && num % 3 && num % 5 && num % 7 && num % 11 && num % 13 && num % 17 && num % 19 && num % 23 && num % 29 && num % 31) == 0)
            {cout << "The number is not prime" << endl;
                if (num % 2 == 0)
                    cout << "The number is divisible by 2." << endl;
                if (num % 3 == 0)
                    cout << "The number is divisible by 3." << endl;
                if (num % 5 == 0)
                    cout << "The number is divisible by 5." << endl;
                if (num % 7 == 0)
                    cout << "The number is divisible by 7." << endl;
                if (num % 11 == 0)
                    cout << "The number is divisible by 11." << endl;
                if (num % 13 == 0)
                    cout << "The number is divisible by 13." << endl;
                if (num % 17 == 0)
                    cout << "The number is divisible by 17." << endl;
                if (num % 19 == 0)
                    cout << "The number is divisible by 19." << endl;
                if (num % 23 == 0)
                    cout << "The number is divisible by 23." << endl;
                if (num % 29 == 0)
                    cout << "The number is divisible by 29." << endl;
                if (num % 31 == 0)
                    cout << "The number is divisible by 31." << endl;
            }
        else
            cout << "The number is prime." << endl;
    }
    else cout << "Data value out of range. Please try again. " << endl;
    
    return 0;
    
}
