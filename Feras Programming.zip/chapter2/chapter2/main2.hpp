//
//  main2.hpp
//  chapter2
//
//  Created by Feras Ahmed on 9/30/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#ifndef main2_hpp
#define main2_hpp

#include <stdio.h>

#endif /* main2_hpp */
