//
//  main.cpp
//  Ch. 2  Problem 18
//
//  Created by Feras Ahmed on 9/13/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#include "iostream"

using namespace std;

const int weeks = 5;
const double tax= .14;
const double clothesAccs= .10;
const double supplies= .01;
const double bonds= .25;

int main(){
    
    double payrateHr;
    double numHrsWorkedPerwk;
    
    
    cout << "Enter your payrate per hour: " << endl;
    cin >> payrateHr;
    
    cout << "Enter the numbers of hours worked this week: " << endl;
    cin >> numHrsWorkedPerwk;
    
    double pretaxincome = (payrateHr*numHrsWorkedPerwk*weeks);
    double netincome = (pretaxincome - (pretaxincome*tax));

    
    cout << "Pre-Tax income: $" << pretaxincome << endl;
    cout << "Post-Tax income: $" << netincome << endl;
    cout << "Money Spent on Clothes and Other Accessories: $" << netincome*clothesAccs << endl;
    cout << "Money Spent on School Supplies: $" << netincome*supplies << endl;
    cout << "Money Spent on Buying Savings Bonds: $" << netincome*bonds << endl;
    cout << "Money Parents Spend on Buying Addtl Bonds: $" << ((netincome*bonds)*.50) << endl;
    
    return 0;
}