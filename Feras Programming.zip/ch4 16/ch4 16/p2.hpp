//
//  p2.hpp
//  ch4 16
//
//  Created by Feras Ahmed on 10/4/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#ifndef p2_hpp
#define p2_hpp

#include <stdio.h>

#endif /* p2_hpp */
