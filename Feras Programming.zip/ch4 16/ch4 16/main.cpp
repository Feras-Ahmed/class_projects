//
//  main.cpp
//  ch4 16
//
//  Created by Feras Ahmed on 10/4/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#include <iostream>
#include <iomanip>

using namespace std;

const double opt2FixedRate = .125;
const double opt3FixedRatefirst4k = .10;
const double opt3FixedRateover4k = .14;


int main(){

    double netprice;
    int estimatedNumSold;
    double bestOption = 0;
    
    cout << fixed << setprecision(2);
    
    cout << "Enter the netprice per novel: $" << endl;
    cin >> netprice;
    
    cout << "Enter the estimated number of novels sold: " << endl;
    cin >> estimatedNumSold;
    
    double opt1 = 5000 + 20000;
    cout << "Royalties from Option 1: $" << opt1 << endl;
    
    double opt2 = (netprice*estimatedNumSold)*opt2FixedRate;
    cout << "Royalities from Option 2: $" << opt2 << endl;
    
    double opt3, opt3a, opt3b;
    
        if (estimatedNumSold < 4000)
            opt3 = (netprice*estimatedNumSold)*opt3FixedRatefirst4k;
        else {
            opt3a = ((estimatedNumSold-4000)*netprice)*opt3FixedRatefirst4k; //check to see if math is correct
            opt3b = (estimatedNumSold*netprice)*opt3FixedRateover4k; //check to see if math is correct
            opt3 = opt3a + opt3b;
        }
        cout << "Royalties from Option 3 is: $" << opt3 << endl;

    
    if (opt1 > opt2 && opt3){
        bestOption = opt1;
        cout << "Your best option is Option 1." << endl;
        }
    else if (opt2 > opt1 && opt3){
        bestOption = opt2;
        cout << "Your best option is Option 2." << endl;
        }
    else if(opt3 > opt1 && opt2){
        bestOption = opt3;
        cout << "Your best option is Option 3." << endl;
        }
    

    return 0;

}