//  main.cpp
//  ch4 20
//  Created by Feras Ahmed on 10/4/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.

#include <iostream>
#include <iomanip>

using namespace std;

const double tenpercentDiscount = .10;
const double twentypercentDiscount = .20;
const double thirtypercentDiscount = .30;
const double threedayDiscount = .05;

int main() {

    cout << fixed << setprecision(2);
    
    double costPerRoom = 0;
    int numofRooms = 0;
    int daysBooked = 0;
    double salestax= 0;
    int discount =0;
    
    cout << "Please enter the cost of renting one room: $" << endl;
    cin >> costPerRoom;
    
    cout <<"Please enter the number of rooms you will be reserving: " << endl;
    cin >> numofRooms;
    
    cout << "Please enter the number of days the rooms will be booked: " << endl;
    cin >> daysBooked;
    
    cout << "Please enter the sales tax (as a percent): " << endl;
    cin >> salestax;
    
    cout << setfill('*') << endl;

    
    if (numofRooms >= 10 && numofRooms <= 19){
        //cout << "The room quantity discount amount is 10%" << endl;
        costPerRoom = costPerRoom-(costPerRoom*tenpercentDiscount);
        discount = 10;
        }
    else if (numofRooms >= 20 && numofRooms <= 29){
        //cout << "The room quantity discount amount is 20%" << endl;
        costPerRoom = costPerRoom-(costPerRoom*twentypercentDiscount);
        discount = 20;
        }
    else if (numofRooms >= 30){
        //cout << "The room quantity discount amount is 30%" << endl;
        costPerRoom = costPerRoom-(costPerRoom*thirtypercentDiscount);
        discount = 30;
        }
    
    if (daysBooked >= 3)
        {costPerRoom = costPerRoom - (costPerRoom*threedayDiscount);
            //cout << "Days booked discount is: 5%" << endl;
            discount = discount + 5;
        }
    
    cout << "The cost of renting one room is: $" << costPerRoom << endl;
    cout << "The total discount on each room is: %" << discount << endl;
    cout << "Total number of rooms booked: " << numofRooms << endl;
    cout << "Total number of days rooms are booked: " << daysBooked << endl;
    
    double subtotalCostofRooms = (costPerRoom*numofRooms*daysBooked);
    cout << "Total cost of the rooms: $" << subtotalCostofRooms << endl;
    
    
    cout << "The sales tax is: " << salestax << "%" << endl;
   
    double costofroomswTax = subtotalCostofRooms*(salestax/100);
    
    
    double totalBillingamount = subtotalCostofRooms+costofroomswTax;
    cout << "The total billing amount is: $" << totalBillingamount << endl;
    
    return 0;

}
