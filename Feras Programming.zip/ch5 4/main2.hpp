//
//  main2.hpp
//  ch5 4
//
//  Created by Feras Ahmed on 10/7/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#ifndef main2_hpp
#define main2_hpp

#include <stdio.h>

#endif /* main2_hpp */
