//
//  main.hpp
//  ch5 4
//
//  Created by Feras Ahmed on 10/6/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
