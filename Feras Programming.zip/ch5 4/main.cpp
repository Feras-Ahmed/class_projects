//
//  main.cpp
//  ch5 4
//
//  Created by Feras Ahmed on 10/6/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#include <iostream>

using namespace std ;

int main ()
{
    char ch , loopstarter = '1' ;
    int i ;
    
    while (loopstarter == '1')
    {
        cout << "Enter a telephone number expresed in letters : " ;
        
        for (i = 0 ; i <= 7 ; i++)
        {
            if(i == 3)
                cout << "-" ;
            
            cin >> ch ;
            
            if(ch == 'A' || ch == 'a' || ch == 'B' || ch == 'b' || ch == 'C' || ch == 'c')
                cout << "2" ;
            if (ch == 'D' || ch == 'd' || ch == 'E' || ch == 'e' || ch == 'F' || ch == 'f')
                cout << "3" ;
            if (ch == 'G' || ch == 'g' || ch == 'H' || ch == 'h' || ch == 'I' || ch == 'i')
                cout << "4" ;
            if (ch == 'J' || ch == 'j' || ch == 'K' || ch == 'k' || ch == 'L' || ch == 'l')
                cout << "5" ;
            if (ch == 'M' || ch == 'm' || ch == 'N' || ch == 'n' || ch == 'O' || ch == 'o')
                cout << "6" ;
            if (ch == 'P' || ch == 'p' || ch == 'Q' || ch == 'q' || ch == 'R' || ch == 'r' || ch =='S' || ch == 's')
                cout << "7" ;
            if (ch == 'T' || ch == 't' || ch == 'U' || ch == 'u' || ch == 'V' || ch == 'v')
                cout << "8" ;
            if (ch == 'W' || ch == 'w' || ch == 'X' || ch == 'x' || ch == 'Y' || ch == 'y' || ch == 'Z' || ch == 'z')
                cout << "9" ;
        }
        cout << endl << endl ;
        
        cin.ignore(100, '\n') ;
        
        cout << "Press 1 to run the program again: " ;
        cin >> loopstarter;
    }
    
    cin.get() ;
    cin.get() ;
    
    return 0 ;
}
