//  main.cpp
//  ch 6 p 8
//  Created by Feras Ahmed on 10/11/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.

#include <iostream>
#include <cmath>
using namespace std;

const double PI = 3.1416;

int distance (int, int, int, int);
int radius (int, int, int, int);
int circumference (int);
int area (int);


int main(){
    
    int num1;
    int num2;
    int num3;
    int num4;
    
    cout << "Using Main to calculate distance \n Enter a point on the circle: " << endl;
    cin >> num1 >> num2;
    
    cout << "Enter another point on the circle: " << endl;
    cin >> num3 >> num4;
    
    cout << "The distance between the two points is: ";
    distance (num1, num2, num3, num4);
    
    radius (num1, num2, num3, num4);
    
    circumference(num1);
    
    area (num1);
    
    return 0;
}

int distance (int x1, int x2, int y1, int y2){
    
    /*cout << "Enter a point on the circle: " << endl;
    cin >> x1 >> x2;
    
    cout << "Enter a point on the circle: " << endl;
    cin >> y1 >> y2; */
    
    int distancex = (x2 - x1) * (x2 - x1);
    int distancey = (y2 - y1) * (y2 - y1);

    int distanceResult = sqrt(distancex + distancey);
    
    cout << distanceResult << endl;
    
    return distanceResult;

}

int radius (int x1, int x2, int y1, int y2){
    
    cout << "\nFunction to calculate Radius \n Enter the center of the circle: " << endl;
    cin >> x1 >> x2;
    
    cout << "Enter any point on the circle: " << endl;
    cin >> y1 >> y2;
    
    cout << "The radius between the two points is: ";
    distance (x1, x2, y1, y2);
    
    return 0;
}

int circumference (int radius){
    
    radius =0;
    
    cout << "\nFunction to calculate Circumference \n Enter the radius: " << endl;
    cin >> radius;
    
    int circumference =0;
    circumference = 2*PI*radius;
    
    cout << "The circumference is: " << circumference << endl; ;
    
    return circumference;
}

int area (int radius){
    radius =0;
    
    cout << "\nFunction to calculate Area \n Enter the radius: " << endl;
    cin >> radius;
    
    int area =0;
    area = PI*(radius*radius);
    
    cout << "The area is: " << area << endl;

    return area;
    
}