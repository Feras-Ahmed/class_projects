//
//  main.cpp
//  ch3 8
//
//  Created by Feras Ahmed on 9/13/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.
//

#include <iostream>
#include <iomanip>
#include <string> 

using namespace std;

int main(){
    
    double netBalance;
    double payment;
    int d1;
    int d2;
    double interest;
    double interestRate;
    double averageDailyBalance;
    
    cout << fixed << showpoint << setprecision(2);
    
    cout << "Enter the balance shown in the bill: " << endl;
    cin >> netBalance;
    
    cout << "Enter the payment made: " << endl;
    cin >> payment;
    
    cout << "Enter the number of days in the billing cycle: " << endl;
    cin >> d1;
    
    cout << "Enter the number of days the payment is made before billing cycle: " << endl;
    cin >> d2;
    
    cout << "Enter the interest rate per month: " << endl;
    cin >> interestRate;
    
    averageDailyBalance = ((netBalance*d1) - (payment*d2))/d1;
    
    interest = averageDailyBalance * interestRate;
    
    cout << "The Interest is: $" << interest << endl;
    
    return 0;
}