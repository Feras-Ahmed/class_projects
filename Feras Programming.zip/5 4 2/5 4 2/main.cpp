/*Chap : 5
 ques : 5
 Program prompt the user to input a telephone number in letters
 and print number in integer....*/

