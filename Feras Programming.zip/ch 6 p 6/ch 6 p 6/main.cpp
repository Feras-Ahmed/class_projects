//  main.cpp
//  ch 6 p 6
//  Created by Feras Ahmed on 10/11/15.
//  Copyright © 2015 Feras Ahmed. All rights reserved.

#include <iostream>
using namespace std;

int reverseDigit (int);

int main() {
    
    int num =0;
    
    reverseDigit(num);
    
    return 0;
}

int reverseDigit (int num){
    
    int reverse = 0;
    
    cout << "Enter an integer: ";
    cin >> num;
    while(num != 0) {
        int remainder = num%10;
        reverse = reverse*10 + remainder;
        num/=10;
    }
    
    cout << "Your interger reversed is: " << reverse << endl;
    
    return reverse;
    
    }
